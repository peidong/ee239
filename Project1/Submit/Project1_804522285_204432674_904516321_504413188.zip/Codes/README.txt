README

Problem1to3.R is for problems 1,2 and 3.
Problem4to5.R is for problems 4 and 5.
And the results folder contains the matlab files for 3D plot.