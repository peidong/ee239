from pybrain.rl.agents.learning import LearningAgent
from pybrain.rl.agents.optimization import OptimizationAgent